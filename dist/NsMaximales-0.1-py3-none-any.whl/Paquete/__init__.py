__titulo__= 'NsMaximales'
__Autores__= 'Yeimi Rodríguez y Gennifer Montaño'
__versión__= '0.1'
__correo__ = "gennifermontanorodriguez@gmail.com o yeimir0000@gmail.com"
__descripción__='NsMaximales se encarga de calcular los n-subárboles maximales y apartir de ellos obtener una base topológica'
