# NsMaximales
NsMaximales se encarga de calcular los n-subarboles maximales y apartir de ellos obtener una base topologica.
